    import javax.swing.*;
    import java.awt.*;
    import javax.swing.border.*;
    class placrorder extends JFrame {
        public placrorder() {
            
            setTitle("Place Order");
            setSize(400, 300);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(new BorderLayout());

            // Create a panel for the order form
            JPanel orderPanel = new JPanel();
            orderPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            orderPanel.setLayout(new GridLayout(5, 2, 10, 10));

            // Add components to the order panel
            orderPanel.add(new JLabel("Product Name:"));
            JTextField productNameField = new JTextField();
            orderPanel.add(productNameField);

            orderPanel.add(new JLabel("Quantity:"));
            JTextField quantityField = new JTextField();
            orderPanel.add(quantityField);

            orderPanel.add(new JLabel("Price:"));
            JTextField priceField = new JTextField();
            orderPanel.add(priceField);

            JButton placeOrderButton = new JButton("Place Order");
            orderPanel.add(placeOrderButton);

            add(orderPanel, BorderLayout.CENTER);
        }

        public static void main(String[] args) {
            SwingUtilities.invokeLater(() -> {
                placrorder frame = new placrorder();
                frame.setVisible(true);
            });
        }
    }

