import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;

class MakePayment extends JFrame {

    public MakePayment() {

        setTitle("Make Payment");
        setSize(450, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Create a panel for the payment form
        JPanel paymentPanel = new JPanel();
        paymentPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        paymentPanel.setLayout(new GridLayout(5, 2, 10, 10));

        // Add components to the payment panel
        paymentPanel.add(new JLabel("Payment Method:"));

        String[] methods = {"Cash", "Credit Card", "Debit Card"};
        JComboBox<String> paymentMethod = new JComboBox<>(methods);
        paymentPanel.add(paymentMethod);

        paymentPanel.add(new JLabel("Payment Information:"));
        JTextField paymentInfoField = new JTextField();
        paymentPanel.add(paymentInfoField);

        paymentPanel.add(new JLabel("Amount:"));
        JTextField amountField = new JTextField();
        paymentPanel.add(amountField);

        JButton payButton = new JButton("Make Payment");
        JButton cancelButton = new JButton("Cancel");

        paymentPanel.add(payButton);
        paymentPanel.add(cancelButton);

        // Payment button action
        payButton.addActionListener(e -> {

            String method = (String) paymentMethod.getSelectedItem();
            String paymentInfo = paymentInfoField.getText();
            String amount = amountField.getText();

            if (paymentInfo.isEmpty() || amount.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please enter all payment information!");
            }
            else {
                try {
                    double totalAmount = Double.parseDouble(amount);

                    if (totalAmount <= 0) {
                        JOptionPane.showMessageDialog(this,
                                "Please enter a valid amount!");
                    }
                    else {
                        int choice = JOptionPane.showConfirmDialog(this,
                                "Confirm Payment of Rs. " + totalAmount + "?",
                                "Payment Confirmation",
                                JOptionPane.YES_NO_OPTION);

                        if (choice == JOptionPane.YES_OPTION) {

                            String paymentId = "PAY" + System.currentTimeMillis();

                            JOptionPane.showMessageDialog(this,
                                    "Payment Successful!\n"
                                    + "Payment Method: " + method + "\n"
                                    + "Amount: Rs. " + totalAmount + "\n"
                                    + "Payment ID: " + paymentId + "\n"
                                    + "Payment Status: Successful");
                        }
                    }
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this,
                            "Please enter a valid amount!");
                }
            }
        });

        // Cancel button action
        cancelButton.addActionListener(e -> {
            dispose();
        });

        add(paymentPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            MakePayment frame = new MakePayment();
            frame.setVisible(true);
        });
    }
}
 
